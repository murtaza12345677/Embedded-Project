/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define zero_low_limit 2
#define zero_high_limit 4
#define zero_TX_count 3

#define one_low_limit 5
#define one_high_limit 7
#define one_TX_count 6

#define low_TX_count 4 // 0 level time on output pin

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim4;

/* USER CODE BEGIN PV */
uint16_t BR_rec_data_L = 0, BR_L_RX_word = 0, BR_L_count = 0,  BR_R_count = 0;
uint8_t BR_L_ON = 0, BR_R_ON = 0, 	BR_L_bit_count = 0, BR_L_word_recived = 0;

uint16_t BR_TX_L_Buffer = 0, BR_TX_L_bit = 0;
uint8_t BR_L_TX_buffer_empty = 0, BR_L_TX_bit_count = 0, BR_L_TX_bit_buffer_empty = 0,
		BR_L_bit_push_counter = 0, BR_L_low_TX_counter = 0, BR_L_low_TX_count = 0;
uint8_t BR_TX_L_Status = 0;  // 0 is ideal, 1 is written by non interrupt program, 2 is busy transmitting
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM4_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start_IT(&htim4);

  BR_TX_L_Buffer = 0xa5a5;
  BR_TX_L_Status = 1;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
//	  if(BR_TX_L_Status == 0)
//	  {
//		  HAL_GPIO_WritePin(GPIOC, LED_Pin, RESET);
//	  }
//	  else if(BR_TX_L_Status == 2)
//	  {
//		  HAL_GPIO_WritePin(GPIOC, LED_Pin, SET);
//	  }


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 720-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 50000;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, DATA_OUT_Pin|GPIO_PIN_9|DATA_R_OUT_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DATA_IN1_Pin */
  GPIO_InitStruct.Pin = DATA_IN1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(DATA_IN1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DATA_IN2_Pin */
  GPIO_InitStruct.Pin = DATA_IN2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(DATA_IN2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : DATA_OUT_Pin PA9 DATA_R_OUT_Pin */
  GPIO_InitStruct.Pin = DATA_OUT_Pin|GPIO_PIN_9|DATA_R_OUT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : DATA_IN3_Pin */
  GPIO_InitStruct.Pin = DATA_IN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(DATA_IN3_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : DATA_IN4_Pin */
  GPIO_InitStruct.Pin = DATA_IN4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(DATA_IN4_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

// timer intterupt program for communication channels

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(BR_L_ON)
	{
		BR_L_count++;
	}

	if(BR_R_ON)
	{
		BR_R_count++;
	}


	//******************************************************************************************

	// START TX buffer transmission on Left channel OK 300324

	//************************************************************************************************
		// left channel word transmit program on communication timer interrupt

			//BR_TX_L_Status   0 is ideal, 1 is written by non interrupt program, 2 is busy transmitting

		// HAL_GPIO_TogglePin(GPIOC, LED_Pin); // interrupt working Test on 300324 OK

			if(BR_TX_L_Status == 1) // buffer has been written by non interrupt
			{
				BR_TX_L_Status = 2;
				//HAL_GPIO_WritePin(GPIOC, LED_Pin, SET);
				BR_L_TX_bit_count = 16;
			}


			if((BR_L_TX_bit_count != 0)  && (BR_TX_L_Status == 2)) // Transmitting word on physical line
			{
				//BR_TX_L_bit = 0x8000 & BR_TX_L_Buffer;
				if(0x8000 & BR_TX_L_Buffer)
				{
					BR_TX_L_bit = 1;
					BR_L_TX_bit_buffer_empty = 1;
					//HAL_GPIO_WritePin(GPIOC, LED_Pin, SET); // working 300324
				}
				else
				{
					BR_TX_L_bit = 0;
					BR_L_TX_bit_buffer_empty = 1;
					//HAL_GPIO_WritePin(GPIOC, LED_Pin, RESET); // working 300324
				}
				BR_TX_L_Status = 3; // bit transmission ON
			}


			// L channel bit transmit program on communication timer interrupt

			if((BR_L_TX_bit_buffer_empty == 1) && (BR_TX_L_Status == 3))
			{

				if(BR_TX_L_bit == 0)
				{
					BR_L_bit_push_counter = zero_TX_count;
					BR_L_TX_bit_buffer_empty = 0;
					HAL_GPIO_WritePin(GPIOA, DATA_OUT_Pin, SET);
					//HAL_GPIO_WritePin(GPIOC, LED_Pin, SET);
				}
				else
				{
					BR_L_bit_push_counter = one_TX_count;
					BR_L_TX_bit_buffer_empty = 0;
					HAL_GPIO_WritePin(GPIOA, DATA_OUT_Pin, SET);
					//HAL_GPIO_WritePin(GPIOC, LED_Pin, SET);
				}
				BR_TX_L_Status = 4; // bit value loaded for transmission
			}

			if((BR_L_bit_push_counter != 0) && (BR_TX_L_Status == 4))
			{
				BR_L_bit_push_counter--;
			}

			if((BR_L_bit_push_counter == 0) && (BR_TX_L_Status == 4))
			{
				HAL_GPIO_WritePin(GPIOA, DATA_OUT_Pin, RESET);
				//HAL_GPIO_WritePin(GPIOC, LED_Pin, RESET);
				BR_L_TX_bit_count--;
				if(BR_L_TX_bit_count == 0)
				{
					BR_TX_L_Status = 0; // word transmitted successfully
					BR_TX_L_Buffer = 0;
				}
				else
				{
					BR_TX_L_Buffer = BR_TX_L_Buffer << 1;
					BR_TX_L_Status = 2;
					BR_L_TX_bit_buffer_empty = 1;
				}
			}

			//******************************************************************************************

			// END TX buffer transmission on Left channel OK 300324

			//************************************************************************************************

}

// left communication channel RX intterupts program

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	switch(GPIO_Pin)
	{
		case DATA_IN1_Pin: // Risign Edge intterupt routine
			BR_L_count = 0;
			BR_L_ON = 1;
			BR_L_bit_count = 0;
			BR_L_word_recived = 0; // if overflow is desigred then modify this line
			break;



		case DATA_IN2_Pin: //  Falling Edge  intterupt routine
			BR_L_ON = 0;
			if((BR_L_count > one_low_limit) && (BR_L_count < one_high_limit))
			{
				BR_rec_data_L = BR_rec_data_L | 1;
				BR_rec_data_L = BR_rec_data_L << 1;
			}
			else if((BR_L_count > zero_low_limit) && (BR_L_count < zero_high_limit))
			{
				BR_rec_data_L = BR_rec_data_L << 1;
			}
			BR_L_bit_count++;
			if(BR_L_bit_count == 16)
			{
				BR_L_RX_word = BR_rec_data_L;
			}
			BR_L_word_recived = 1;
			break;


// right communication channel RX intterupts program

		case DATA_IN3_Pin: // Risign Edge intterupt routine
			BR_R_ON = 1;
			break;



		case DATA_IN4_Pin: //  Falling Edge  intterupt routine
			BR_R_ON = 0;
			break;

	}
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
